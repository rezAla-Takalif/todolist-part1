﻿namespace TodoList
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.مدیریتکارهاToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.کارجدیدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.کارجدیدToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.مدیریتکارهاToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(756, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // مدیریتکارهاToolStripMenuItem
            // 
            this.مدیریتکارهاToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.مدیریتکارهاToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.کارجدیدToolStripMenuItem});
            this.مدیریتکارهاToolStripMenuItem.Name = "مدیریتکارهاToolStripMenuItem";
            this.مدیریتکارهاToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.مدیریتکارهاToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.مدیریتکارهاToolStripMenuItem.Text = "کارها";
            // 
            // کارجدیدToolStripMenuItem
            // 
            this.کارجدیدToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.کارجدیدToolStripMenuItem1});
            this.کارجدیدToolStripMenuItem.Name = "کارجدیدToolStripMenuItem";
            this.کارجدیدToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.کارجدیدToolStripMenuItem.Text = "مدیریت کارها";
            // 
            // کارجدیدToolStripMenuItem1
            // 
            this.کارجدیدToolStripMenuItem1.Name = "کارجدیدToolStripMenuItem1";
            this.کارجدیدToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.کارجدیدToolStripMenuItem1.Text = "کار جدید";
            this.کارجدیدToolStripMenuItem1.Click += new System.EventHandler(this.کارجدیدToolStripMenuItem1_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 447);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "mainForm";
            this.Text = "مدیریت کننده کارها";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem مدیریتکارهاToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem کارجدیدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem کارجدیدToolStripMenuItem1;
    }
}

