﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace TodoList
{
    static class Program
    {
        static public string connectionString = "Provider=SQLOLEDB;Data Source=. ;Initial Catalog=TodoList;Integrated Security=SSPI";
        static public OleDbConnection Con = new OleDbConnection(connectionString);
        static public OleDbCommand Cmd = new OleDbCommand("", Con);

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new mainForm());
        }
    }
}
