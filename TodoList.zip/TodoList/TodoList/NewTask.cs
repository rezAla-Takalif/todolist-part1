﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TodoList
{
    public partial class NewTask : Form
    {
        public NewTask()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtCode.Text = "";
            txtTask.Text = "";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (validateFormData() == false) return;

            Program.Con.Open();

            Program.Cmd.CommandText = "INSERT INTO TaskCat (Id,Task) VALUES (" + txtCode.Text + ",N'" + txtTask.Text + "')";
            if (Convert.ToInt32(Program.Cmd.ExecuteNonQuery()) == 1)
            {
                MessageBox.Show("عملیات درج با موفقیت انجام شد", "موفق !", MessageBoxButtons.OK, MessageBoxIcon.None);
                txtCode.Text = "";
                txtTask.Text = "";
            }
            else
            {
                MessageBox.Show("عملیات درج با مشکلی روبرو شده است", "خطا !", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Program.Con.Close();

        }

        private Boolean validateFormData()
        {
            txtCode.Text = txtCode.Text.Trim();
            txtTask.Text = txtTask.Text.Trim();

            if (txtCode.Text == "")
            {
                MessageBox.Show("کد وارد نشده است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txtTask.Text == "")
            {
                MessageBox.Show("عنوان وارد نشده است", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }


            Program.Con.Open();
            Program.Cmd.CommandText = "SELECT COUNT(*) FROM TaskCat WHERE Task=N'" + txtTask.Text + "'";
            int n;
            n = Convert.ToInt32(Program.Cmd.ExecuteScalar());
            Program.Con.Close();
            if (n >= 1)
            {
                MessageBox.Show("عنوان وارد شده تکراری است", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            Program.Con.Open();
            Program.Cmd.CommandText = "SELECT COUNT(*) FROM TaskCat WHERE Id=" + txtCode.Text;
            int k;
            k = Convert.ToInt32(Program.Cmd.ExecuteScalar());
            Program.Con.Close();
            if (k >= 1)
            {
                MessageBox.Show("کد وارد شده تکراری است", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }




            return true;
        }

        private void txtCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }
    }
}
